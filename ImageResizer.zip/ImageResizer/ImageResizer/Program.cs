﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ImageResizer
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = @"C:\Projects\Desert.jpg"; //select source path

            ImageResizer resizer = new ImageResizer(307200, path, @"C:\Projects\result.jpg");
            resizer.ScaleImage();
        }
    }
}
