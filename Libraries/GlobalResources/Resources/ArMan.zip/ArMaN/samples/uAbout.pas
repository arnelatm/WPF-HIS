unit uAbout;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, jpeg, ExtCtrls;

type
  TForm2 = class(TForm)
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    Label9: TLabel;
    Label10: TLabel;
    Image2: TImage;
    Label11: TLabel;
    Label12: TLabel;
    procedure Label11Click(Sender: TObject);
    procedure Label12Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form2: TForm2;

implementation
uses shellapi ;
{$R *.dfm}

procedure TForm2.Label11Click(Sender: TObject);
begin
ShellExecute(Handle, 'open', PChar('http://www.orwah.net'), nil, nil, SW_SHOW);

end;

procedure TForm2.Label12Click(Sender: TObject);
begin
ShellExecute(Handle, 'open', PChar('mailto:webmaster@orwah.net'), nil, nil, SW_SHOW);

end;

end.
